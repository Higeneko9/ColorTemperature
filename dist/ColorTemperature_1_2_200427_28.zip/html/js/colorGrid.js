"use strict";
class ColorGrid {
    numCells() { return this._numCells; }
    numWingCells() { return this._numWingCells; }
    gridSize() { return this._gridSize; }
    constructor(initialWingCells) {
        this.pos = { x: 0, y: 0 };
        this.setWingCellCount(initialWingCells);
    }
    setWingCellCount(newNumWingCells) {
        this._numWingCells = newNumWingCells;
        this._numCells = this._numWingCells * 2 + 1;
        this._totalCellCount = this._numCells * this._numCells;
        this._cells = new Array(this._totalCellCount);
        this.adjustCellSize();
    }
    resize(newGridSize) {
        this._rawGridSize = newGridSize;
        return this.adjustCellSize();
    }
    updateColors(callback) {
        var it = {
            x: 0, y: 0, isCenterX: false, isCenterY: false
        };
        var cellIdx = 0;
        for (it.y = -this._numWingCells; it.y <= this._numWingCells; ++it.y) {
            it.isCenterY = it.y == 0;
            for (it.x = -this._numWingCells; it.x <= this._numWingCells; ++it.x) {
                it.isCenterX = it.x == 0;
                this._cells[cellIdx++] = callback(it);
            }
        }
    }
    draw(ctx) {
        var cellIdx = 0;
        var y = this.pos.y;
        for (var i = 0; i < this._numCells; ++i, y += this._cellSize) {
            var x = this.pos.x;
            for (var j = 0; j < this._numCells; ++j, x += this._cellSize) {
                ctx.fillStyle = this._cells[cellIdx++].toHexString();
                ctx.fillRect(x, y, this._cellSize, this._cellSize);
            }
        }
    }
    getColor(x, y) {
        var ix = Math.floor(x / this._cellSize);
        var iy = Math.floor(y / this._cellSize);
        return (0 <= ix && ix < this._numCells && 0 <= iy && iy < this._numCells) ?
            this._cells[iy * this._numCells + ix] : null;
    }
    adjustCellSize() {
        this._cellSize = Math.floor(this._rawGridSize / this._numCells);
        this._gridSize = this._cellSize * this._numCells;
        return this._gridSize;
    }
}
