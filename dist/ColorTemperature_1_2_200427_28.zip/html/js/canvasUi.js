"use strict";
var CanvasUI;
(function (CanvasUI) {
    class Control {
        constructor() {
            this.showBounds = false;
            this.isVisible = true;
        }
        bounds() { return this._bounds; }
        onMouseMove(pos) { return false; }
        onMouseDown(pos) { return false; }
        onMouseUp(pos) { return false; }
        setBounds(bounds) {
            this._bounds = bounds;
        }
        captureMouse() {
            return this.manager.captureMouse(this);
        }
        releaseMouse() {
            return this.manager.releaseMouse(this);
        }
    }
    CanvasUI.Control = Control;
    let SliderOrientation;
    (function (SliderOrientation) {
        SliderOrientation[SliderOrientation["Horizontal"] = 0] = "Horizontal";
        SliderOrientation[SliderOrientation["Vertical"] = 1] = "Vertical";
    })(SliderOrientation = CanvasUI.SliderOrientation || (CanvasUI.SliderOrientation = {}));
    class Slider extends Control {
        constructor() {
            super();
            this._valueChangedCallbacks = new Array();
            this._thumbDraggingOffset = null;
            this.value = 0;
            this.orientation = SliderOrientation.Horizontal;
        }
        onValueChanged(callback) {
            this._valueChangedCallbacks.push(callback);
        }
        setBounds(bounds) {
            super.setBounds(bounds);
            this.computePositions();
            this.updateThumbRect();
        }
        onMouseUp(pos) {
            if (this._thumbDraggingOffset != null) {
                this.releaseMouse();
                this._thumbDraggingOffset = null;
            }
            return false;
        }
        onMouseDown(pos) {
            if (this._thumbRc.containsPoint(pos)) {
                this._thumbDraggingOffset = new Vector2(this._thumbPos.x - pos.x, this._thumbPos.y - pos.y);
                this.captureMouse();
            }
            return false;
        }
        onMouseMove(pos) {
            if (this._thumbDraggingOffset == null)
                return false;
            var a = this.computePositions();
            var newValue = (this.orientation == SliderOrientation.Horizontal) ?
                Slider.computeValue(a.p1.x, a.p2.x, pos.x + this._thumbDraggingOffset.x) :
                Slider.computeValue(a.p1.y, a.p2.y, pos.y + this._thumbDraggingOffset.y);
            this.value = newValue;
            this.updateThumbRect();
            for (var callback of this._valueChangedCallbacks) {
                callback(newValue);
            }
            return false;
        }
        draw(context) {
            var a = this.computePositions();
            var p1 = a.p1;
            var p2 = a.p2;
            var mtx = a.mtx;
            var thumbPos = this._thumbPos;
            var trackWidth = Slider._trackWidth;
            var ctx = context;
            ctx.beginPath();
            ctx.strokeStyle = '#757575';
            ctx.lineCap = 'round';
            ctx.lineWidth = trackWidth;
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            ctx.beginPath();
            ctx.strokeStyle = '#789ec8';
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(thumbPos.x, thumbPos.y);
            ctx.stroke();
            ctx.strokeStyle = '#202020';
            ctx.fillStyle = '#f0f0f0';
            ctx.lineWidth = 1;
            ctx.beginPath();
            for (var i = 0; i < Slider._thumbVertices.length; ++i) {
                var v = Slider._thumbVertices[i];
                var p = Vector2.add(thumbPos, Vector2.transformNormal(v, mtx));
                if (i == 0) {
                    ctx.moveTo(p.x, p.y);
                }
                else {
                    ctx.lineTo(p.x, p.y);
                }
            }
            ctx.fill();
            ctx.stroke();
            if (this.showBounds) {
                ctx.strokeStyle = 'yellow';
                var rc = this._thumbRc;
                ctx.strokeRect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
            }
        }
        computePositions() {
            var p1;
            var p2;
            var rc = this._bounds;
            var mtx;
            if (this.orientation == SliderOrientation.Horizontal) {
                var cy = MathHelper.lerp(rc.top, rc.bottom, 0.5);
                p1 = new Vector2(rc.left, cy);
                p2 = new Vector2(rc.right, cy);
                mtx = Matrix.createRotationZ(MathHelper.toRadians(90));
            }
            else {
                var cx = MathHelper.lerp(rc.left, rc.right, 0.5);
                p1 = new Vector2(cx, rc.bottom);
                p2 = new Vector2(cx, rc.top);
                mtx = Matrix.identity();
            }
            this._thumbPos = Vector2.lerp(p1, p2, this.value);
            return { p1: p1, p2: p2, mtx: mtx };
        }
        updateThumbRect() {
            var ts = Slider._thumbSize / 2 + 4;
            this._thumbRc = new Rect(this._thumbPos.x - ts, this._thumbPos.y - ts, this._thumbPos.x + ts, this._thumbPos.y + ts);
        }
        static computeValue(p1, p2, p) {
            return MathHelper.saturate((p - p1) / (p2 - p1));
        }
    }
    Slider._trackWidth = 4;
    Slider._thumbSize = 12;
    Slider._thumbVertices = [
        new Vector2(-6, 0),
        new Vector2(1, -6),
        new Vector2(6, -6),
        new Vector2(6, 6),
        new Vector2(1, 6),
        new Vector2(-6, 0),
    ];
    CanvasUI.Slider = Slider;
    class Manager {
        constructor(viewport, canvas) {
            this._captureedControl = null;
            this._viewport = viewport;
            this._canvas = canvas;
            this._context = canvas.getContext('2d');
            this._controls = new Array();
            var me = this;
            this.handleMouseEvent('pointerdown', function (p, c) {
                return c.onMouseDown(p);
            });
            document.addEventListener('pointermove', (e) => {
                if (me._captureedControl == null)
                    return;
                me._captureedControl.onMouseMove(Point.subtract(new Point(e.clientX, e.clientY), Rect.fromElementBounds(me._viewport).pos()));
            });
            document.addEventListener('pointerup', (e) => {
                if (me._captureedControl == null)
                    return;
                me._captureedControl.onMouseUp(Point.subtract(new Point(e.clientX, e.clientY), Rect.fromElementBounds(me._viewport).pos()));
            });
        }
        addControl(control) {
            control.manager = this;
            this._controls.push(control);
        }
        captureMouse(control) {
            this._captureedControl = control;
            return true;
        }
        releaseMouse(control) {
            this._captureedControl = null;
            return true;
        }
        draw() {
            for (var c of this._controls) {
                c.draw(this._context);
                if (c.showBounds) {
                    var rc = c.bounds();
                    this._context.strokeStyle = 'red';
                    this._context.lineWidth = 1;
                    this._context.strokeRect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
                }
            }
        }
        handleMouseEvent(eventName, callback) {
            var me = this;
            this._canvas.addEventListener(eventName, (e) => {
                var pos = Point.subtract(new Point(e.clientX, e.clientY), Rect.fromElementBounds(me._canvas).pos());
                if (me._captureedControl) {
                    callback(pos, me._captureedControl);
                }
                else {
                    for (var c of me._controls) {
                        if (c.bounds().containsPoint(pos) == false)
                            continue;
                        if (callback(pos, c))
                            break;
                    }
                }
            });
        }
    }
    CanvasUI.Manager = Manager;
})(CanvasUI || (CanvasUI = {}));
;
