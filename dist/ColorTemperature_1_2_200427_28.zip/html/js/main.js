"use strict";
class ColorTemperature {
    constructor() {
        this.NumWingCells = 3;
        this.MiredRangeMin = 10;
        this.MiredRangeMax = 100;
        this.LuminanceRangeMin = 0.1;
        this.LuminanceRangeMax = 2.0;
        this.NumCells = this.NumWingCells * 2 + 1;
        this._miredScale = 0.1;
        this._luminanceScale = 0.1;
    }
    initialize() {
        var me = this;
        this._sliders = [null, null];
        this._uiManager = new CanvasUI.Manager(document.getElementById('viewport'), document.getElementById('mainCanvas'));
        this.grid = new ColorGrid(3);
        this.updateColors(new RgbColor(0.8, 0.8, 0.8));
        this.resizeWatcher = new ResizeWatcher(document.getElementById('screen'), function () { me.onResize(); });
        document.getElementById('mainCanvas').addEventListener("mousedown", (e) => {
            var color = me.grid.getColor(e.offsetX, e.offsetY);
            if (color)
                me.setColor(color);
        });
    }
    setColor(color) {
        if (this._selectedColor.r != color.r ||
            this._selectedColor.g != color.g ||
            this._selectedColor.b != color.b) {
            setColor(color);
            this.updateColors(color);
            this.draw();
        }
    }
    updateColors(color) {
        this._selectedColor = color;
        var centerXyz = ColorSpace.linearSrgbToCieXyz(color);
        var centerLab = centerXyz.toCieLab();
        var d65 = 1.4388 / 1.438 * 6500;
        var centerMired = ColorTemperature.kelvinToMired(d65);
        var centerTempXyz = CieChromaticityXyColor
            .fromTemperature(ColorTemperature.miredToKelvin(centerMired))
            .toCieXyz(centerXyz.y);
        var centerTempLab = centerTempXyz.toCieLab();
        var miredStep = MathHelper.lerp(this.MiredRangeMin, this.MiredRangeMax, this._miredScale) / this.grid.numWingCells();
        var luminaceStep = MathHelper.lerp(this.LuminanceRangeMin, this.LuminanceRangeMax, this._luminanceScale) / this.grid.numWingCells();
        this.grid.updateColors(function (it) {
            var tempLab = centerLab;
            if (!it.isCenterX) {
                var mired = centerMired + it.x * miredStep;
                tempLab = CieChromaticityXyColor
                    .fromTemperature(ColorTemperature.miredToKelvin(mired))
                    .toCieXyz(centerXyz.y).toCieLab();
                tempLab.a = centerLab.a + (tempLab.a - centerTempLab.a);
                tempLab.b = centerLab.b + (tempLab.b - centerTempLab.b);
            }
            var xyz = new CieLabColor(MathHelper.clamp(tempLab.l - it.y * luminaceStep, 0, 100), tempLab.a, tempLab.b).toCieXyz();
            return ColorSpace.cieXyzToLinearSrgb(xyz);
        });
    }
    onResize() {
        var scrRc = document.getElementById('screen').getBoundingClientRect();
        var sw = scrRc.width;
        var sh = scrRc.height;
        var cx = 0;
        var cy = 0;
        var padding = 8;
        var vpSize;
        if (sw > sh) {
            vpSize = sh - padding;
            cx = (sw - vpSize) / 2;
            cy = padding / 2;
        }
        else {
            vpSize = sw - padding;
            cx = padding / 2;
            cy = (sh - vpSize) / 2;
        }
        var vp = document.getElementById('viewport');
        vp.style.width = vpSize.toString() + 'px';
        vp.style.height = vpSize.toString() + 'px';
        vp.style.left = cx.toString() + 'px';
        vp.style.top = cy.toString() + 'px';
        var mainCanvas = document.getElementById('mainCanvas');
        var ctx = mainCanvas.getContext('2d');
        var rc = mainCanvas.getBoundingClientRect();
        ctx.clearRect(0, 0, rc.width, rc.height);
        ctx.canvas.width = vpSize;
        ctx.canvas.height = vpSize;
        this.grid.resize(vpSize - 32);
        this.resizeSliders();
        this.draw();
    }
    ;
    draw() {
        var mainCanvas = document.getElementById('mainCanvas');
        var ctx = mainCanvas.getContext('2d');
        var rc = mainCanvas.getBoundingClientRect();
        ctx.clearRect(0, 0, rc.width, rc.height);
        this.grid.draw(ctx);
        this._uiManager.draw();
    }
    resizeSliders() {
        var me = this;
        if (this._sliders[0] == null) {
            var slider = new CanvasUI.Slider();
            slider.orientation = CanvasUI.SliderOrientation.Horizontal;
            slider.value = this._miredScale;
            slider.onValueChanged(function (value) {
                me._miredScale = value;
                me.updateColors(me._selectedColor);
                me.draw();
            });
            this._uiManager.addControl(slider);
            this._sliders[0] = slider;
        }
        if (this._sliders[1] == null) {
            var slider = new CanvasUI.Slider();
            slider.orientation = CanvasUI.SliderOrientation.Vertical;
            slider.value = this._luminanceScale;
            slider.onValueChanged(function (value) {
                me._luminanceScale = value;
                me.updateColors(me._selectedColor);
                me.draw();
            });
            this._uiManager.addControl(slider);
            this._sliders[1] = slider;
        }
        var size = this.grid.gridSize();
        this._sliders[0].setBounds(new Rect(8, size, size - 8, size + 32));
        this._sliders[1].setBounds(new Rect(size, 8, size + 32, size - 8));
    }
    static kelvinToMired(kelvin) {
        return 1000000 / kelvin;
    }
    static miredToKelvin(mired) {
        return 1000000 / mired;
    }
}
var csInterface = new CSInterface();
var gExtensionID = undefined;
if (typeof (csInterface.getExtensionID) == "function") {
    try {
        gExtensionID = csInterface.getExtensionID();
    }
    catch (Exception) {
        csInterface = null;
    }
}
else {
    csInterface = null;
}
var eventSet = 1936028772;
var gRegisteredEvents = [eventSet];
var colorTemperature = new ColorTemperature();
function PhotoshopCallbackUnique(csEvent) {
    if (typeof csEvent.data === "string") {
        var eventDataString = csEvent.data.replace("ver1,{", "{");
        var eventData = JSON.parse(eventDataString);
        var args = eventData.eventData;
        if (eventData.eventID === eventSet && args.hasOwnProperty("source") && args.hasOwnProperty("to")) {
            if (args.source === "eyeDropperSample" || args.source === "photoshopPicker" ||
                args.source === "colorPickerWheel" || args.source === "colorPickerPanel") {
                if (args.to._obj === "RGBColor") {
                    var t = args.to;
                    colorTemperature.updateColors(new RgbColor(t.red / 255, t.grain / 255, t.blue / 255));
                    colorTemperature.draw();
                }
                else if (args.to._obj === "HSBColorClass") {
                    var t = args.to;
                    colorTemperature.updateColors(RgbColor.fromHsv(t.hue._value, t.saturation, t.brightness));
                    colorTemperature.draw();
                }
            }
        }
    }
}
function setColor(color) {
    var r = Math.floor(MathHelper.saturate(color.r) * 255);
    var g = Math.floor(MathHelper.saturate(color.g) * 255);
    var b = Math.floor(MathHelper.saturate(color.b) * 255);
    if (csInterface)
        csInterface.evalScript(`setColor(${r}, ${g}, ${b})`);
}
colorTemperature.initialize();
if (csInterface) {
    csInterface.addEventListener("com.adobe.PhotoshopJSONCallback" + gExtensionID, PhotoshopCallbackUnique);
    var csEvent = new CSEvent("com.adobe.PhotoshopRegisterEvent", "APPLICATION");
    csEvent.extensionId = gExtensionID;
    csEvent.data = gRegisteredEvents.toString();
    csInterface.dispatchEvent(csEvent);
}
