"use strict";
class Point {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    static add(value1, value2) {
        return new Point(value1.x + value2.x, value1.y + value2.y);
    }
    static subtract(value1, value2) {
        return new Point(value1.x - value2.x, value1.y - value2.y);
    }
}
class Rect {
    constructor(left, top, right, bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }
    static fromElementBounds(element) {
        var rc = element.getBoundingClientRect();
        return new Rect(rc.left, rc.top, rc.right, rc.bottom);
    }
    pos() { return new Point(this.left, this.top); }
    width() { return this.right - this.left; }
    height() { return this.bottom - this.top; }
    containsPoint(point) {
        return this.left <= point.x && point.x < this.right &&
            this.top <= point.y && point.y < this.bottom;
    }
}
