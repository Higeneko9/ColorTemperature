"use strict";
class RgbColor {
    constructor(r, g, b) {
        this.r = r;
        this.g = g;
        this.b = b;
    }
    static fromCssRgb(rgbText) {
        var rgb = rgbText.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
        return new RgbColor(parseInt(rgb[1], 10) / 255.0, parseInt(rgb[2], 10) / 255.0, parseInt(rgb[3], 10) / 255.0);
    }
    static fromHsv(h, s, v) {
        while (h >= 360.0)
            h -= 360.0;
        while (h < 0)
            h += 360.0;
        h = MathHelper.saturate(h / 360.0);
        s = MathHelper.saturate(s / 100.0);
        v = MathHelper.saturate(v / 100.0);
        var i = Math.floor(h * 6);
        var f = h * 6 - i;
        var p = v * (1 - s);
        var q = v * (1 - f * s);
        var t = v * (1 - (1 - f) * s);
        var r, g, b;
        switch (i % 6) {
            case 0:
                r = v, g = t, b = p;
                break;
            case 1:
                r = q, g = v, b = p;
                break;
            case 2:
                r = p, g = v, b = t;
                break;
            case 3:
                r = p, g = q, b = v;
                break;
            case 4:
                r = t, g = p, b = v;
                break;
            case 5:
                r = v, g = p, b = q;
                break;
        }
        return new RgbColor(r, g, b);
    }
    static saturate(rgbColor) {
        return new RgbColor(Math.max(0.0, Math.min(1.0, rgbColor.r)), Math.max(0.0, Math.min(1.0, rgbColor.g)), Math.max(0.0, Math.min(1.0, rgbColor.b)));
    }
    toHexString() {
        var r = Math.min(255, Math.max(0, Math.floor(this.r * 255)));
        var g = Math.min(255, Math.max(0, Math.floor(this.g * 255)));
        var b = Math.min(255, Math.max(0, Math.floor(this.b * 255)));
        return '#' + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
    }
}
class CieXyzColor {
    constructor(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    static fromCieChromaticityXy(cieChromaticityXyColor, y) {
        var xy = cieChromaticityXyColor;
        return new CieXyzColor(y / xy.y * xy.x, y, y / xy.y * (1.0 - xy.x - xy.y));
    }
    static fromCieLab(cieLabColor) {
        const c1 = 6 / 29;
        const c2 = 3 * c1 * c1;
        const c3 = 4 / 29;
        var l = 1 / 116 * (cieLabColor.l + 16);
        var x = l + 1 / 500 * cieLabColor.a;
        var y = l;
        var z = l - 1 / 200 * cieLabColor.b;
        x = x > c1 ? x * x * x : c2 * (x - c3);
        y = y > c1 ? y * y * y : c2 * (y - c3);
        z = z > c1 ? z * z * z : c2 * (z - c3);
        return new CieXyzColor(95.047 * x, 100.0 * y, 108.883 * z);
    }
    toCieLab() { return CieLabColor.fromCieXyz(this); }
}
class CieChromaticityXyColor {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    static fromTemperature(kelvin) {
        var t = kelvin;
        var t2 = t * t;
        var u = (0.860117757 + 1.54118254 * 1e-4 * t + 1.28641212 * 1e-7 * t2) /
            (1 + 8.42420235 * 1e-4 * t + 7.08145163 * 1e-7 * t2);
        var v = (0.317398726 + 4.22806245 * 1e-5 * t + 4.20481691 * 1e-8 * t2) /
            (1 - 2.89741816 * 1e-5 * t + 1.61456053 * 1e-7 * t2);
        var d = 2 * u - 8 * v + 4;
        return new CieChromaticityXyColor(3 * u / d, 2 * v / d);
    }
    toCieXyz(y) {
        return CieXyzColor.fromCieChromaticityXy(this, y);
    }
}
class CieLabColor {
    constructor(l, a, b) {
        this.l = l;
        this.a = a;
        this.b = b;
    }
    static fromCieXyz(cieXyzColor) {
        const c1 = (6 / 29) ** 3;
        const c2 = ((29 / 6) ** 2) / 3;
        var x = cieXyzColor.x / 95.047;
        var y = cieXyzColor.y / 100.0;
        var z = cieXyzColor.z / 108.883;
        x = x > c1 ? x ** (1 / 3) : c2 * x + 4 / 29;
        y = y > c1 ? y ** (1 / 3) : c2 * y + 4 / 29;
        z = z > c1 ? z ** (1 / 3) : c2 * z + 4 / 29;
        return new CieLabColor(116 * y - 16, 500 * (x - y), 200 * (y - z));
    }
    toCieXyz() { return CieXyzColor.fromCieLab(this); }
}
class HsvColor {
    constructor(h, s, v) {
        this.h = h;
        this.s = s;
        this.v = v;
    }
}
class ColorSpace {
    static cieXyzToLinearSrgb(cieXyzColor) {
        var v = Vector3.Transform(new Vector3(cieXyzColor.x, cieXyzColor.y, cieXyzColor.z), ColorSpace._xyzToLinearSrgb);
        return new RgbColor(v.x, v.y, v.z);
    }
    static linearSrgbToCieXyz(rgbColor) {
        var v = Vector3.Transform(new Vector3(rgbColor.r, rgbColor.g, rgbColor.b), ColorSpace._linearSrgbToXyz);
        return new CieXyzColor(v.x, v.y, v.z);
    }
    static computeColorSpaceConversionMatrix(red, green, blue, white) {
        var r = new Vector3(red.x, red.y, 1 - (red.x + red.y));
        var g = new Vector3(green.x, green.y, 1 - (green.x + green.y));
        var b = new Vector3(blue.x, blue.y, 1 - (blue.x + blue.y));
        var w = new Vector3(white.x, white.y, 1 - (white.x + white.y));
        w.x /= white.y;
        w.y /= white.y;
        w.z /= white.y;
        var m = new Matrix(r.x, r.y, r.z, 0, g.x, g.y, g.z, 0, b.x, b.y, b.z, 0, 0, 0, 0, 1);
        var invMtx = Matrix.Invert(m);
        var scale = Vector3.TransformNormal(w, invMtx);
        m.m11 *= scale.x;
        m.m12 *= scale.x;
        m.m13 *= scale.x;
        m.m21 *= scale.y;
        m.m22 *= scale.y;
        m.m23 *= scale.y;
        m.m31 *= scale.z;
        m.m32 *= scale.z;
        m.m33 *= scale.z;
        return m;
    }
}
ColorSpace._linearSrgbToXyz = ColorSpace.computeColorSpaceConversionMatrix(new CieChromaticityXyColor(0.64, 0.33), new CieChromaticityXyColor(0.3, 0.6), new CieChromaticityXyColor(0.15, 0.06), new CieChromaticityXyColor(0.3127, 0.3290));
ColorSpace._xyzToLinearSrgb = Matrix.Invert(ColorSpace._linearSrgbToXyz);
