//---------------------------------------------------------------------------------------
//  Color Tempperature for Photoshop CC 2018
//=======================================================================================

Description:
    This is a plug-in for Photoshop CC which shows warmer and cooler colors of current color.
    Also, it shows lighter and darker color too.

How to install:
    1. Make sure your Photoshop is up to date (This package tested against Photoshop CC 2018)
    2. Unzip this package.
    2. In Photoshop, select a menu "File -> Scripts -> browse" and pick "Install Color Temperature1.1.jsx"
    3. Follow the installer's instructions.
    4. Restart Photoshop.
    5. Select a menu "Window -> Extensions -> Color Temperature"

If installer doesn't work, try the following instruction:
    1. Unzip this package
    2. Copy "html" folder contents to:
        For Windows : %APPDATA%\Adobe\CEP\extensions\net.higeneko.color-temperature\
        For Mac OS : /Library/Application Support/Adobe/CEP/extensions/net.higeneko.color-temperature/
        Important: You may need to create those folders manually.
    3. Restart Photoshop.
