"use strict";
var Matrix = (function () {
    function Matrix(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44) {
        this.m11 = m11;
        this.m12 = m12;
        this.m13 = m13;
        this.m14 = m14;
        this.m21 = m21;
        this.m22 = m22;
        this.m23 = m23;
        this.m24 = m24;
        this.m31 = m31;
        this.m32 = m32;
        this.m33 = m33;
        this.m34 = m34;
        this.m41 = m41;
        this.m42 = m42;
        this.m43 = m43;
        this.m44 = m44;
    }
    Matrix.identity = function () { return Matrix._identity; };
    Matrix.createRotationZ = function (radians) {
        var c = Math.cos(radians);
        var s = Math.sin(radians);
        return new Matrix(c, s, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0);
    };
    Matrix.prototype.getDeterminant = function () {
        var a = this.m11, b = this.m12, c = this.m13, d = this.m14;
        var e = this.m21, f = this.m22, g = this.m23, h = this.m24;
        var i = this.m31, j = this.m32, k = this.m33, l = this.m34;
        var m = this.m41, n = this.m42, o = this.m43, p = this.m44;
        var kp_lo = k * p - l * o;
        var jp_ln = j * p - l * n;
        var jo_kn = j * o - k * n;
        var ip_lm = i * p - l * m;
        var io_km = i * o - k * m;
        var in_jm = i * n - j * m;
        return a * (f * kp_lo - g * jp_ln + h * jo_kn) -
            b * (e * kp_lo - g * ip_lm + h * io_km) +
            c * (e * jp_ln - f * ip_lm + h * in_jm) -
            d * (e * jo_kn - f * io_km + g * in_jm);
    };
    Matrix.Invert = function (matrix) {
        var a = matrix.m11, b = matrix.m12, c = matrix.m13, d = matrix.m14;
        var e = matrix.m21, f = matrix.m22, g = matrix.m23, h = matrix.m24;
        var i = matrix.m31, j = matrix.m32, k = matrix.m33, l = matrix.m34;
        var m = matrix.m41, n = matrix.m42, o = matrix.m43, p = matrix.m44;
        var kp_lo = k * p - l * o;
        var jp_ln = j * p - l * n;
        var jo_kn = j * o - k * n;
        var ip_lm = i * p - l * m;
        var io_km = i * o - k * m;
        var in_jm = i * n - j * m;
        var a11 = +(f * kp_lo - g * jp_ln + h * jo_kn);
        var a12 = -(e * kp_lo - g * ip_lm + h * io_km);
        var a13 = +(e * jp_ln - f * ip_lm + h * in_jm);
        var a14 = -(e * jo_kn - f * io_km + g * in_jm);
        var det = a * a11 + b * a12 + c * a13 + d * a14;
        if (Math.abs(det) < 1e-8) {
            return null;
        }
        var invDet = 1.0 / det;
        var m11 = a11 * invDet;
        var m21 = a12 * invDet;
        var m31 = a13 * invDet;
        var m41 = a14 * invDet;
        var m12 = -(b * kp_lo - c * jp_ln + d * jo_kn) * invDet;
        var m22 = +(a * kp_lo - c * ip_lm + d * io_km) * invDet;
        var m32 = -(a * jp_ln - b * ip_lm + d * in_jm) * invDet;
        var m42 = +(a * jo_kn - b * io_km + c * in_jm) * invDet;
        var gp_ho = g * p - h * o;
        var fp_hn = f * p - h * n;
        var fo_gn = f * o - g * n;
        var ep_hm = e * p - h * m;
        var eo_gm = e * o - g * m;
        var en_fm = e * n - f * m;
        var m13 = +(b * gp_ho - c * fp_hn + d * fo_gn) * invDet;
        var m23 = -(a * gp_ho - c * ep_hm + d * eo_gm) * invDet;
        var m33 = +(a * fp_hn - b * ep_hm + d * en_fm) * invDet;
        var m43 = -(a * fo_gn - b * eo_gm + c * en_fm) * invDet;
        var gl_hk = g * l - h * k;
        var fl_hj = f * l - h * j;
        var fk_gj = f * k - g * j;
        var el_hi = e * l - h * i;
        var ek_gi = e * k - g * i;
        var ej_fi = e * j - f * i;
        var m14 = -(b * gl_hk - c * fl_hj + d * fk_gj) * invDet;
        var m24 = +(a * gl_hk - c * el_hi + d * ek_gi) * invDet;
        var m34 = -(a * fl_hj - b * el_hi + d * ej_fi) * invDet;
        var m44 = +(a * fk_gj - b * ek_gi + c * ej_fi) * invDet;
        return new Matrix(m11, m12, m13, m14, m21, m22, m23, m24, m31, m32, m33, m34, m41, m42, m43, m44);
    };
    return Matrix;
}());
Matrix._identity = new Matrix(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
