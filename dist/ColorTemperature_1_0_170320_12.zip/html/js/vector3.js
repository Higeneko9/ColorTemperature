"use strict";
var Vector3 = (function () {
    function Vector3(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    Vector3.zero = function () { return Vector3._zero; };
    Vector3.Transform = function (position, matrix) {
        return new Vector3(position.x * matrix.m11 + position.y * matrix.m21 + position.z * matrix.m31 + matrix.m41, position.x * matrix.m12 + position.y * matrix.m22 + position.z * matrix.m32 + matrix.m42, position.x * matrix.m13 + position.y * matrix.m23 + position.z * matrix.m33 + matrix.m43);
    };
    Vector3.TransformNormal = function (normal, matrix) {
        return new Vector3(normal.x * matrix.m11 + normal.y * matrix.m21 + normal.z * matrix.m31, normal.x * matrix.m12 + normal.y * matrix.m22 + normal.z * matrix.m32, normal.x * matrix.m13 + normal.y * matrix.m23 + normal.z * matrix.m33);
    };
    return Vector3;
}());
Vector3._zero = new Vector3(0, 0, 0);
