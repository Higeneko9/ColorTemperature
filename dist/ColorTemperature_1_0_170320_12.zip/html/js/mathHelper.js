"use strict";
var MathHelper = (function () {
    function MathHelper() {
    }
    MathHelper.Pi = function () { return MathHelper._pi; };
    MathHelper.TwoPi = function () { return MathHelper._twoPi; };
    MathHelper.PiOver2 = function () { return MathHelper._piOver2; };
    MathHelper.PiOver4 = function () { return MathHelper._piOver4; };
    MathHelper.toRadians = function (degree) {
        return degree * MathHelper._piOver180;
    };
    MathHelper.toDegrees = function (radians) {
        return radians * MathHelper._180OverPi;
    };
    MathHelper.lerp = function (value1, value2, t) {
        return value1 + (value2 - value1) * t;
    };
    MathHelper.saturate = function (value) {
        return Math.max(0, Math.min(value, 1));
    };
    MathHelper.clamp = function (val, minValue, maxValue) {
        return Math.max(minValue, Math.min(val, maxValue));
    };
    return MathHelper;
}());
MathHelper._pi = Math.PI;
MathHelper._twoPi = Math.PI * 2.0;
MathHelper._piOver2 = Math.PI / 2.0;
MathHelper._piOver4 = Math.PI / 4.0;
MathHelper._piOver180 = Math.PI / 180.0;
MathHelper._180OverPi = 180.0 / Math.PI;
