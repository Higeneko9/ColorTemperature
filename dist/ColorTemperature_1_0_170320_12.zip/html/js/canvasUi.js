"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CanvasUI;
(function (CanvasUI) {
    var Control = (function () {
        function Control() {
            this.showBounds = false;
            this.isVisible = true;
        }
        Control.prototype.bounds = function () { return this._bounds; };
        Control.prototype.onMouseMove = function (pos) { return false; };
        Control.prototype.onMouseDown = function (pos) { return false; };
        Control.prototype.onMouseUp = function (pos) { return false; };
        Control.prototype.setBounds = function (bounds) {
            this._bounds = bounds;
        };
        Control.prototype.captureMouse = function () {
            return this.manager.captureMouse(this);
        };
        Control.prototype.releaseMouse = function () {
            return this.manager.releaseMouse(this);
        };
        return Control;
    }());
    CanvasUI.Control = Control;
    var SliderOrientation;
    (function (SliderOrientation) {
        SliderOrientation[SliderOrientation["Horizontal"] = 0] = "Horizontal";
        SliderOrientation[SliderOrientation["Vertical"] = 1] = "Vertical";
    })(SliderOrientation = CanvasUI.SliderOrientation || (CanvasUI.SliderOrientation = {}));
    var Slider = (function (_super) {
        __extends(Slider, _super);
        function Slider() {
            var _this = _super.call(this) || this;
            _this._valueChangedCallbacks = new Array();
            _this._thumbDraggingOffset = null;
            _this.value = 0;
            _this.orientation = SliderOrientation.Horizontal;
            return _this;
        }
        Slider.prototype.onValueChanged = function (callback) {
            this._valueChangedCallbacks.push(callback);
        };
        Slider.prototype.setBounds = function (bounds) {
            _super.prototype.setBounds.call(this, bounds);
            this.computePositions();
            this.updateThumbRect();
        };
        Slider.prototype.onMouseUp = function (pos) {
            if (this._thumbDraggingOffset != null) {
                this.releaseMouse();
                this._thumbDraggingOffset = null;
            }
            return false;
        };
        Slider.prototype.onMouseDown = function (pos) {
            if (this._thumbRc.containsPoint(pos)) {
                this._thumbDraggingOffset = new Vector2(this._thumbPos.x - pos.x, this._thumbPos.y - pos.y);
                this.captureMouse();
            }
            return false;
        };
        Slider.prototype.onMouseMove = function (pos) {
            if (this._thumbDraggingOffset == null)
                return false;
            var a = this.computePositions();
            var newValue = (this.orientation == SliderOrientation.Horizontal) ?
                Slider.computeValue(a.p1.x, a.p2.x, pos.x + this._thumbDraggingOffset.x) :
                Slider.computeValue(a.p1.y, a.p2.y, pos.y + this._thumbDraggingOffset.y);
            console.log("value:" + newValue + ", y1:" + a.p1.y + ", y2:" + a.p1.y + ", pos.y:" + pos.y);
            this.value = newValue;
            this.updateThumbRect();
            for (var _i = 0, _a = this._valueChangedCallbacks; _i < _a.length; _i++) {
                var callback = _a[_i];
                callback(newValue);
            }
            return false;
        };
        Slider.prototype.draw = function (context) {
            var a = this.computePositions();
            var p1 = a.p1;
            var p2 = a.p2;
            var mtx = a.mtx;
            var thumbPos = this._thumbPos;
            var trackWidth = Slider._trackWidth;
            var ctx = context;
            ctx.beginPath();
            ctx.strokeStyle = '#757575';
            ctx.lineCap = 'round';
            ctx.lineWidth = trackWidth;
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
            ctx.beginPath();
            ctx.strokeStyle = '#789ec8';
            ctx.moveTo(p1.x, p1.y);
            ctx.lineTo(thumbPos.x, thumbPos.y);
            ctx.stroke();
            ctx.strokeStyle = '#202020';
            ctx.fillStyle = '#f0f0f0';
            ctx.lineWidth = 1;
            ctx.beginPath();
            for (var i = 0; i < Slider._thumbVertices.length; ++i) {
                var v = Slider._thumbVertices[i];
                var p = Vector2.add(thumbPos, Vector2.transformNormal(v, mtx));
                if (i == 0) {
                    ctx.moveTo(p.x, p.y);
                }
                else {
                    ctx.lineTo(p.x, p.y);
                }
            }
            ctx.fill();
            ctx.stroke();
            if (this.showBounds) {
                ctx.strokeStyle = 'yellow';
                var rc = this._thumbRc;
                ctx.strokeRect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
            }
        };
        Slider.prototype.computePositions = function () {
            var p1;
            var p2;
            var rc = this._bounds;
            var mtx;
            if (this.orientation == SliderOrientation.Horizontal) {
                var cy = MathHelper.lerp(rc.top, rc.bottom, 0.5);
                p1 = new Vector2(rc.left, cy);
                p2 = new Vector2(rc.right, cy);
                mtx = Matrix.createRotationZ(MathHelper.toRadians(90));
            }
            else {
                var cx = MathHelper.lerp(rc.left, rc.right, 0.5);
                p1 = new Vector2(cx, rc.bottom);
                p2 = new Vector2(cx, rc.top);
                mtx = Matrix.identity();
            }
            this._thumbPos = Vector2.lerp(p1, p2, this.value);
            return { p1: p1, p2: p2, mtx: mtx };
        };
        Slider.prototype.updateThumbRect = function () {
            var ts = Slider._thumbSize / 2 + 4;
            this._thumbRc = new Rect(this._thumbPos.x - ts, this._thumbPos.y - ts, this._thumbPos.x + ts, this._thumbPos.y + ts);
        };
        Slider.computeValue = function (p1, p2, p) {
            return MathHelper.saturate((p - p1) / (p2 - p1));
        };
        return Slider;
    }(Control));
    Slider._trackWidth = 4;
    Slider._thumbSize = 12;
    Slider._thumbVertices = [
        new Vector2(-6, 0),
        new Vector2(1, -6),
        new Vector2(6, -6),
        new Vector2(6, 6),
        new Vector2(1, 6),
        new Vector2(-6, 0),
    ];
    CanvasUI.Slider = Slider;
    var Manager = (function () {
        function Manager(viewport, canvas) {
            this._captureedControl = null;
            this._viewport = viewport;
            this._canvas = canvas;
            this._controls = new Array();
            var me = this;
            var mainCanvas = this._canvas[0];
            this._context = mainCanvas.getContext('2d');
            this.handleMouseEvent('mousedown', function (p, c) {
                return c.onMouseDown(p);
            });
            $(document).mousemove(function (e) {
                if (me._captureedControl == null)
                    return;
                var ox = parseInt(me._viewport.css('left'));
                var oy = parseInt(me._viewport.css('top'));
                me._captureedControl.onMouseMove(new Point(e.clientX - ox, e.clientY - oy));
            });
            $(document).mouseup(function (e) {
                if (me._captureedControl == null)
                    return;
                var ox = parseInt(me._viewport.css('left'));
                var oy = parseInt(me._viewport.css('top'));
                me._captureedControl.onMouseUp(new Point(e.clientX - ox, e.clientY - oy));
            });
        }
        Manager.prototype.addControl = function (control) {
            control.manager = this;
            this._controls.push(control);
        };
        Manager.prototype.captureMouse = function (control) {
            this._captureedControl = control;
            return true;
        };
        Manager.prototype.releaseMouse = function (control) {
            this._captureedControl = null;
            return true;
        };
        Manager.prototype.draw = function () {
            for (var _i = 0, _a = this._controls; _i < _a.length; _i++) {
                var c = _a[_i];
                c.draw(this._context);
                if (c.showBounds) {
                    var rc = c.bounds();
                    this._context.strokeStyle = 'red';
                    this._context.lineWidth = 1;
                    this._context.strokeRect(rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top);
                }
            }
        };
        Manager.prototype.handleMouseEvent = function (eventName, callback) {
            var me = this;
            this._canvas.on(eventName, function (e) {
                var pos = new Point(e.offsetX, e.offsetY);
                if (me._captureedControl) {
                    callback(pos, me._captureedControl);
                }
                else {
                    for (var _i = 0, _a = me._controls; _i < _a.length; _i++) {
                        var c = _a[_i];
                        if (c.bounds().containsPoint(pos) == false)
                            continue;
                        if (callback(pos, c))
                            break;
                    }
                }
            });
        };
        return Manager;
    }());
    CanvasUI.Manager = Manager;
})(CanvasUI || (CanvasUI = {}));
;
