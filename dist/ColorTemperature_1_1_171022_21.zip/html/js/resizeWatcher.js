"use strict";
class ResizeWatcher {
    constructor(element, callback) {
        this.element = element;
        this.callback = callback;
        this.lastWidth = -1;
        this.lastHeight = -1;
        var requestAnimationFrame = window.requestAnimationFrame;
        var me = this;
        var checkResize = function () {
            var w = me.element.width();
            var h = me.element.height();
            if (w != me.lastWidth || h != me.lastHeight) {
                me.lastWidth = w;
                me.lastHeight = h;
                me.callback();
            }
            requestAnimationFrame(checkResize);
        };
        requestAnimationFrame(checkResize);
    }
}
