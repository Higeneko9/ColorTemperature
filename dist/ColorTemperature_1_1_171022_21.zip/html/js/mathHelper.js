"use strict";
class MathHelper {
    static Pi() { return MathHelper._pi; }
    static TwoPi() { return MathHelper._twoPi; }
    static PiOver2() { return MathHelper._piOver2; }
    static PiOver4() { return MathHelper._piOver4; }
    static toRadians(degree) {
        return degree * MathHelper._piOver180;
    }
    static toDegrees(radians) {
        return radians * MathHelper._180OverPi;
    }
    static lerp(value1, value2, t) {
        return value1 + (value2 - value1) * t;
    }
    static saturate(value) {
        return Math.max(0, Math.min(value, 1));
    }
    static clamp(val, minValue, maxValue) {
        return Math.max(minValue, Math.min(val, maxValue));
    }
}
MathHelper._pi = Math.PI;
MathHelper._twoPi = Math.PI * 2.0;
MathHelper._piOver2 = Math.PI / 2.0;
MathHelper._piOver4 = Math.PI / 4.0;
MathHelper._piOver180 = Math.PI / 180.0;
MathHelper._180OverPi = 180.0 / Math.PI;
