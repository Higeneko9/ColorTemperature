"use strict";
class Vector2 {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
    static zero() { return Vector2._zero; }
    static transform(position, matrix) {
        return new Vector2(position.x * matrix.m11 + position.y * matrix.m21 + matrix.m41, position.x * matrix.m12 + position.y * matrix.m22 + matrix.m42);
    }
    static transformNormal(normal, matrix) {
        return new Vector2(normal.x * matrix.m11 + normal.y * matrix.m21, normal.x * matrix.m12 + normal.y * matrix.m22);
    }
    static lerp(value1, value2, amount) {
        return new Vector2(value1.x + (value2.x - value1.x) * amount, value1.y + (value2.y - value1.y) * amount);
    }
    static add(value1, value2) {
        return new Vector2(value1.x + value2.x, value1.y + value2.y);
    }
}
Vector2._zero = new Vector2(0, 0);
